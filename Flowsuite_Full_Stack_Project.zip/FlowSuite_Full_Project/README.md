# FlowSuite — Flask Task & Workspace Dashboard

A portfolio-friendly Flask + SQLite workspace app with:
- Home / landing page
- Register, login and logout
- Task CRUD (add, delete, change status)
- Task analytics with graphs
- Pricing plans with demo upgrade flow
- Contact form saved to SQLite
- Per-user task data isolation
- Responsive dark/navy SaaS UI

## Run on Windows (VS Code)
1. Open this folder in VS Code.
2. Terminal → New Terminal.
3. Create virtual environment (if not present):
   ```powershell
   python -m venv venv
   ```
4. Activate:
   ```powershell
   .\venv\Scripts\Activate
   ```
5. Install packages:
   ```powershell
   pip install -r requirements.txt
   ```
6. Start:
   ```powershell
   python app.py
   ```
7. Visit http://127.0.0.1:5000

First registration creates your account and workspace. The pricing upgrade is a demo only and does not charge money.

## Project structure
```
FlowSuite_Full_Project/
├── app.py
├── requirements.txt
├── README.md
├── flowsuite.db        # created on first run
├── templates/
└── static/
    ├── css/style.css
    └── js/analytics.js
```

## Notes
- SQLite database is created automatically on first run.
- For production: set `SECRET_KEY`, turn off debug mode, use a production WSGI server, add CSRF protection, HTTPS, email verification/password reset, and real payment provider integration only with test keys.
