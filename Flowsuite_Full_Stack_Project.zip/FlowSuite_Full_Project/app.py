from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime, date
import sqlite3, os

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-in-production")
DB_PATH = os.path.join(os.path.dirname(__file__), "flowsuite.db")

PLANS = {
    "Free": {"price": 0, "task_limit": 30, "label": "Free"},
    "Starter": {"price": 499, "task_limit": 250, "label": "Starter"},
    "Professional": {"price": 999, "task_limit": 10000, "label": "Professional"},
}

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            organization TEXT NOT NULL,
            plan TEXT NOT NULL DEFAULT 'Free',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'To Do',
            priority TEXT NOT NULL DEFAULT 'Medium',
            due_date TEXT DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        """)

init_db()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please log in to open your workspace.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def current_user():
    if not session.get("user_id"):
        return None
    with db() as con:
        return con.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()

def task_count(uid):
    with db() as con:
        return con.execute("SELECT COUNT(*) FROM tasks WHERE user_id=?", (uid,)).fetchone()[0]

@app.context_processor
def inject_globals():
    return {"plans": PLANS, "year": datetime.now().year}

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        organization = request.form.get("organization", "").strip() or f"{name}'s Workspace"
        password = request.form.get("password", "")
        if not name or not email or len(password) < 8:
            flash("Enter all fields. Password must be at least 8 characters.", "danger")
            return render_template("register.html")
        try:
            with db() as con:
                cur = con.execute("INSERT INTO users(name,email,password_hash,organization,plan) VALUES(?,?,?,?,?)",
                    (name, email, generate_password_hash(password), organization, "Free"))
                uid = cur.lastrowid
            session["user_id"] = uid
            session["user_name"] = name
            flash("Workspace created! Welcome to FlowSuite.", "success")
            return redirect(url_for("tasks_page"))
        except sqlite3.IntegrityError:
            flash("That email is already registered. Try logging in.", "danger")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with db() as con:
            user = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            flash(f"Welcome back, {user['name']}!", "success")
            return redirect(url_for("tasks_page"))
        flash("Email or password is incorrect.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have logged out.", "info")
    return redirect(url_for("home"))

@app.route("/tasks", methods=["GET", "POST"])
@login_required
def tasks_page():
    user = current_user()
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        priority = request.form.get("priority", "Medium")
        due_date = request.form.get("due_date", "")
        allowed = {"Low", "Medium", "High"}
        if title:
            limit = PLANS.get(user["plan"], PLANS["Free"])["task_limit"]
            if task_count(user["id"]) >= limit:
                flash(f"Task limit reached for {user['plan']} plan. See Pricing to upgrade.", "warning")
            else:
                with db() as con:
                    con.execute("INSERT INTO tasks(user_id,title,description,priority,due_date) VALUES(?,?,?,?,?)",
                        (user["id"], title, description, priority if priority in allowed else "Medium", due_date))
                flash("Task added.", "success")
        else:
            flash("Task title is required.", "danger")
        return redirect(url_for("tasks_page"))
    filter_status = request.args.get("status", "")
    with db() as con:
        if filter_status in ("To Do", "In Progress", "Done"):
            tasks = con.execute("SELECT * FROM tasks WHERE user_id=? AND status=? ORDER BY created_at DESC",
                               (user["id"], filter_status)).fetchall()
        else:
            tasks = con.execute("SELECT * FROM tasks WHERE user_id=? ORDER BY created_at DESC",
                               (user["id"],)).fetchall()
    return render_template("tasks.html", tasks=tasks, filter_status=filter_status, user=user)

@app.route("/task/<int:task_id>/status", methods=["POST"])
@login_required
def update_task_status(task_id):
    status = request.form.get("status")
    if status not in ("To Do", "In Progress", "Done"):
        flash("Invalid status.", "danger")
        return redirect(url_for("tasks_page"))
    with db() as con:
        con.execute("UPDATE tasks SET status=? WHERE id=? AND user_id=?", (status, task_id, session["user_id"]))
    flash("Task status updated.", "success")
    return redirect(request.referrer or url_for("tasks_page"))

@app.route("/task/<int:task_id>/delete", methods=["POST"])
@login_required
def delete_task(task_id):
    with db() as con:
        con.execute("DELETE FROM tasks WHERE id=? AND user_id=?", (task_id, session["user_id"]))
    flash("Task deleted.", "info")
    return redirect(url_for("tasks_page"))

@app.route("/analytics")
@login_required
def analytics():
    uid = session["user_id"]
    with db() as con:
        counts = {s: con.execute("SELECT COUNT(*) FROM tasks WHERE user_id=? AND status=?", (uid,s)).fetchone()[0]
                  for s in ("To Do", "In Progress", "Done")}
        total = sum(counts.values())
        recent = con.execute("SELECT title,status,priority,created_at FROM tasks WHERE user_id=? ORDER BY id DESC LIMIT 8", (uid,)).fetchall()
    return render_template("analytics.html", counts=counts, total=total, recent=recent, user=current_user())

@app.route("/pricing", methods=["GET", "POST"])
def pricing():
    user = current_user()
    if request.method == "POST":
        if not user:
            flash("Create an account or log in before choosing a plan.", "warning")
            return redirect(url_for("register"))
        plan = request.form.get("plan")
        if plan not in PLANS:
            flash("Invalid plan.", "danger")
        else:
            with db() as con:
                con.execute("UPDATE users SET plan=? WHERE id=?", (plan, user["id"]))
            flash(f"Plan changed to {plan} (demo checkout). No payment was charged.", "success")
        return redirect(url_for("pricing"))
    return render_template("pricing.html", user=user)

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        message = request.form.get("message", "").strip()
        if name and email and message:
            with db() as con:
                con.execute("INSERT INTO contacts(user_id,name,email,message) VALUES(?,?,?,?)",
                           (session.get("user_id"), name, email, message))
            flash("Message received. Thanks for reaching out!", "success")
            return redirect(url_for("contact"))
        flash("Please fill in all fields.", "danger")
    return render_template("contact.html", user=current_user())

@app.route("/health")
def health():
    return jsonify({"status": "ok", "app": "FlowSuite"})

if __name__ == "__main__":
    app.run(debug=True)
